// src/App.jsx
import { BrowserRouter, Routes, Route, Outlet } from "react-router-dom";
import { DishesProvider } from "./store/dishes";
import { UsersProvider } from "./store/users";

import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Dishes from "./pages/Dishes";
import DishDetails from "./pages/DishDetails";
import Users from "./pages/Users";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";

import MealPlan from "./pages/user/MealPlan";

import AdminLogin from "./pages/AdminLogin";
import AdminRoute from "./components/AdminRoute";

// Customer profile (mobile-first page)
import CustomerProfile from "./pages/CustomerProfile";

// If you use these pages, keep imports; otherwise remove.
import AddOrder from "./pages/AddOrder";
import AllOrders from "./pages/AllOrders";

function AdminLayout() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <Outlet />
    </div>
  );
}

function MobileLayout() {
  return (
    <div className="min-h-screen bg-white">
      <Outlet />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <UsersProvider>
        <DishesProvider>
          <Routes>
            <Route path="/admin-login" element={<AdminLogin />} />

            <Route
              element={
                <AdminRoute>
                  <AdminLayout />
                </AdminRoute>
              }
            >
              <Route path="/" element={<Home />} />
              <Route path="/addorder" element={<AddOrder />} />
              <Route path="/all-orders" element={<AllOrders />} />
              <Route path="/dishes" element={<Dishes />} />
              <Route path="/dishes/:id" element={<DishDetails />} />
              <Route path="/users" element={<Users />} />
              <Route path="/login" element={<Login />} />
            </Route>

            {/* Mobile routes (customer-facing) */}
            <Route element={<MobileLayout />}>
              <Route path="/meal" element={<MealPlan />} />
              <Route path="/customer/:id" element={<CustomerProfile />} />
            </Route>

            <Route path="*" element={<NotFound />} />
          </Routes>
        </DishesProvider>
      </UsersProvider>
    </BrowserRouter>
  );
}
