// src/pages/CustomerProfile.jsx
import React, { useEffect, useMemo, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { api } from "../lib/axios";
import WalletStatementModal from "../components/WalletStatementModal";

/* -------------------------------- helpers -------------------------------- */
const rupee = (n) => `₹${Number(n || 0).toFixed(2)}`;
const fmt0 = (n) => (Number.isFinite(Number(n)) ? Number(n).toFixed(0) : "0");

const badge = (status) =>
  Number(status) === 1 ? (
    <span className="text-green-700 bg-green-100 px-2 py-0.5 rounded">Active</span>
  ) : (
    <span className="text-gray-700 bg-gray-100 px-2 py-0.5 rounded">Inactive</span>
  );

const idFrom = (u, fallback) => u?._id || u?.user_uuid || u?.uuid || fallback;
const titleFrom = (u) =>
  (u?.user_title && String(u.user_title).trim()) ||
  (u?.name && String(u.name).trim()) ||
  (u?.mobile_number && String(u.mobile_number).trim()) ||
  "Customer";

function initials(name = "") {
  const parts = String(name).trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "SB";
  return (parts[0][0] + (parts[1]?.[0] || "")).toUpperCase();
}

function normalizeNutrition(obj = {}) {
  const num = (v) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  };
  return {
    calories: num(obj.calories ?? obj.kcal ?? obj.energy),
    protein: num(obj.protein),
    fat: num(obj.fat ?? obj.fats),
    carbs: num(obj.carbs ?? obj.carbohydrates),
  };
}
const mergeNutrition = (a, b) => (b ? normalizeNutrition(b) : a ? normalizeNutrition(a) : { calories: 0, protein: 0, fat: 0, carbs: 0 });
const mulNut = (n, t) => ({
  calories: Math.round((n.calories || 0) * (t || 1)),
  protein: Math.round((n.protein || 0) * (t || 1)),
  fat: Math.round((n.fat || 0) * (t || 1)),
  carbs: Math.round((n.carbs || 0) * (t || 1)),
});

/* ------------------------------ data loaders ----------------------------- */

async function loadUser(userIdFromRoute) {
  const res = await api.get(`/api/users/${userIdFromRoute}`);
  return res.data || res;
}

/** Try multiple endpoints/param names and normalize response to {items, total} */
async function loadOrdersForUser(userId) {
  // 1) Common GET shapes
  const getTries = [
    { url: "/api/orders", params: { user: userId } },
    { url: "/api/orders", params: { user_uuid: userId } },
    { url: "/api/orders", params: { customer: userId } },
    { url: `/api/orders/by-user/${userId}`, params: {} },
    { url: "/api/admin/orders", params: { user: userId } },
    { url: "/api/orders/list", params: { user: userId } },
    { url: "/api/order", params: { user: userId } },
  ];

  for (const t of getTries) {
    try {
      const { data } = await api.get(t.url, { params: t.params });
      const norm = normalizeOrdersResponse(data);
      if (norm) return norm;
    } catch {
      /* try next */
    }
  }

  // 2) Common POST shape used by many admin “All Orders” pages
  const postTries = [
    {
      url: "/api/admin/orders",
      body: { page: 1, rows: 1, user_uuid: userId }, // rows=1 is enough to pick up total count in many APIs
    },
    {
      url: "/api/admin/orders/search",
      body: { page: 1, rows: 1, filters: { user_uuid: userId } },
    },
    {
      url: "/api/orders/search",
      body: { page: 1, rows: 1, user_uuid: userId },
    },
  ];

  for (const t of postTries) {
    try {
      const { data } = await api.post(t.url, t.body);
      const norm = normalizeOrdersResponse(data);
      if (norm) return norm;
    } catch {
      /* try next */
    }
  }

  return { items: [], total: 0, debug: "No matching orders endpoint responded with list." };
}

function normalizeOrdersResponse(data) {
  // Array
  if (Array.isArray(data)) return { items: data, total: data.length };
  // {data:[...], total?}
  if (data && Array.isArray(data.data))
    return { items: data.data, total: Number(data.total ?? data.count ?? data.totalCount ?? data.data.length) };
  // {rows:[...], total?}
  if (data && Array.isArray(data.rows))
    return { items: data.rows, total: Number(data.total ?? data.count ?? data.totalCount ?? data.rows.length) };
  // {items:[...], total?}
  if (data && Array.isArray(data.items))
    return { items: data.items, total: Number(data.total ?? data.items.length) };
  // {result:[...], total?}
  if (data && Array.isArray(data.result))
    return { items: data.result, total: Number(data.total ?? data.result.length) };
  return null;
}

async function loadDishesBatch(ids) {
  if (!ids?.length) return {};
  try {
    const { data } = await api.get("/api/dishes/batch", { params: { ids: ids.join(",") } });
    const arr = Array.isArray(data) ? data : data?.data;
    if (!Array.isArray(arr)) return {};
    const map = {};
    for (const d of arr) {
      map[String(d._id)] = {
        title: d.title || d.name || "",
        nutrition: normalizeNutrition(d.nutrition || d),
      };
    }
    return map;
  } catch {
    return {};
  }
}

/* --------------------------------- page ---------------------------------- */

export default function CustomerProfile() {
  const { id: routeId } = useParams();

  const [user, setUser] = useState(null);
  const [orders, setOrders] = useState([]);
  const [ordersTotal, setOrdersTotal] = useState(0);
  const [dishMap, setDishMap] = useState({});
  const [loading, setLoading] = useState(true);
  const [stmtOpen, setStmtOpen] = useState(false);
  const [ordersDebug, setOrdersDebug] = useState(""); // tiny hint if nothing matched

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        setLoading(true);

        // 1) user
        const u = await loadUser(routeId);
        if (!alive) return;
        setUser(u);

        const uid = idFrom(u, routeId);

        // 2) orders (robust)
        const resp = await loadOrdersForUser(uid);
        if (!alive) return;
        setOrders(resp.items || []);
        setOrdersTotal(Number(resp.total || (resp.items ? resp.items.length : 0)));
        setOrdersDebug(resp.debug || "");

        // 3) dish nutrition (only if item-level nutrition missing)
        const needIds = new Set();
        for (const o of resp.items || []) {
          for (const it of o?.dish_details || []) {
            const dId = String(it.dish_uuid || it.dish_id || "");
            const hasNut = !!(it.nutrition && (it.nutrition.calories || it.nutrition.kcal || it.nutrition.energy));
            if (dId && !hasNut) needIds.add(dId);
          }
        }
        if (needIds.size) {
          const map = await loadDishesBatch(Array.from(needIds));
          if (!alive) return;
          setDishMap(map);
        }
      } catch {
        if (alive) {
          setUser(null);
          setOrders([]);
          setOrdersTotal(0);
          setDishMap({});
          setOrdersDebug("Failed to fetch user or orders.");
        }
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, [routeId]);

  /* ------------- nutrition aggregation ------------- */
  const nutritionRows = useMemo(() => {
    const acc = new Map();
    for (const o of orders) {
      for (const it of o?.dish_details || []) {
        const key = String(it.dish_uuid || it.dish_id || it.title || "dish");
        const qty = Number(it.quantity || 1);
        const known = dishMap[String(it.dish_uuid || it.dish_id || "")];
        const title = it.title || known?.title || "Dish";
        const per = mergeNutrition(it.nutrition, known?.nutrition);

        const prev = acc.get(key);
        if (prev) {
          prev.qty += qty;
          prev.per = prev.per || per;
        } else {
          acc.set(key, { title, qty, per });
        }
      }
    }
    return Array.from(acc.values()).map((r) => ({ ...r, total: mulNut(r.per || {}, r.qty) }));
  }, [orders, dishMap]);

  const totals = useMemo(() => {
    const t = { calories: 0, protein: 0, fat: 0, carbs: 0 };
    for (const r of nutritionRows) {
      t.calories += r.total.calories || 0;
      t.protein += r.total.protein || 0;
      t.fat += r.total.fat || 0;
      t.carbs += r.total.carbs || 0;
    }
    return t;
  }, [nutritionRows]);

  const wallet = Number(user?.wallet_balance) || 0;
  const uidForStatement = idFrom(user, routeId);

  return (
    <section className="max-w-6xl mx-auto p-4 space-y-4">
      {/* HEADER */}
      <div className="bg-white border rounded-2xl p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-3 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-green-600 text-white flex items-center justify-center text-lg font-semibold">
            {initials(titleFrom(user))}
          </div>
          <div>
            <div className="text-xl font-semibold">
              {titleFrom(user)} <span className="ml-3 align-middle">{badge(user?.status)}</span>
            </div>
            <div className="text-sm text-gray-600">{user?.mobile_number || "—"}</div>
            <div className="text-xs text-gray-500">ID: {uidForStatement}</div>
          </div>
        </div>

        <div className="flex gap-2">
          <Link to="/" className="px-3 py-2 rounded-lg border hover:bg-gray-50">
            Home
          </Link>
        </div>
      </div>

      {/* SUMMARY CARDS */}
      <div className="grid sm:grid-cols-2 gap-3">
        <div className="bg-white border rounded-2xl p-4 shadow-sm flex items-center justify-between">
          <div>
            <div className="text-sm text-gray-500">Wallet Balance</div>
            <div className="text-2xl font-semibold">{rupee(wallet)}</div>
          </div>
          <button
            onClick={() => setStmtOpen(true)}
            className="px-3 py-2 rounded-lg bg-green-600 text-white hover:bg-green-700"
          >
            View Statement
          </button>
        </div>

        <div className="bg-white border rounded-2xl p-4 shadow-sm">
          <div className="text-sm text-gray-500">Orders</div>
          <div className="text-2xl font-semibold">{ordersTotal}</div>
          {/* tiny hint if nothing matched; doesn't show when there are orders */}
          {ordersTotal === 0 && ordersDebug && (
            <div className="text-xs text-gray-400 mt-1">{ordersDebug}</div>
          )}
        </div>
      </div>

      {/* NUTRITION */}
      <div className="bg-white border rounded-2xl shadow-sm">
        <div className="border-b px-3 pt-3">
          <div className="flex gap-2">
            <button className="px-3 py-2 rounded-t-lg border-b-2 border-green-600 text-green-700">
              Nutritional Info
            </button>
          </div>
        </div>

        <div className="p-3">
          {loading ? (
            <div className="text-sm text-gray-500">Loading…</div>
          ) : nutritionRows.length === 0 ? (
            <div className="text-sm text-gray-600">No orders found with nutrition data.</div>
          ) : (
            <div className="space-y-3">
              <div className="overflow-x-auto">
                <table className="min-w-full text-sm border rounded-lg">
                  <thead>
                    <tr className="bg-gray-50 text-left">
                      <th className="px-3 py-2 border">Dish</th>
                      <th className="px-3 py-2 border text-right">Times ordered</th>
                      <th className="px-3 py-2 border text-right">Per serving (kcal)</th>
                      <th className="px-3 py-2 border text-right">Protein (g)</th>
                      <th className="px-3 py-2 border text-right">Fat (g)</th>
                      <th className="px-3 py-2 border text-right">Carbs (g)</th>
                      <th className="px-3 py-2 border text-right">Total kcal</th>
                    </tr>
                  </thead>
                  <tbody>
                    {nutritionRows.map((r, i) => (
                      <tr key={i} className="hover:bg-gray-50">
                        <td className="px-3 py-2 border">{r.title}</td>
                        <td className="px-3 py-2 border text-right">{r.qty}</td>
                        <td className="px-3 py-2 border text-right">{fmt0(r.per?.calories)}</td>
                        <td className="px-3 py-2 border text-right">{fmt0(r.per?.protein)}</td>
                        <td className="px-3 py-2 border text-right">{fmt0(r.per?.fat)}</td>
                        <td className="px-3 py-2 border text-right">{fmt0(r.per?.carbs)}</td>
                        <td className="px-3 py-2 border text-right font-medium">{fmt0(r.total?.calories)}</td>
                      </tr>
                    ))}
                    <tr className="bg-green-50 font-semibold">
                      <td className="px-3 py-2 border">Total</td>
                      <td className="px-3 py-2 border text-right">—</td>
                      <td className="px-3 py-2 border text-right">—</td>
                      <td className="px-3 py-2 border text-right">{fmt0(totals.protein)}</td>
                      <td className="px-3 py-2 border text-right">{fmt0(totals.fat)}</td>
                      <td className="px-3 py-2 border text-right">{fmt0(totals.carbs)}</td>
                      <td className="px-3 py-2 border text-right">{fmt0(totals.calories)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="text-xs text-gray-500">
                * Per-serving values are taken from each dish’s nutrition details. Total = per-serving × times ordered.
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Wallet statement modal */}
      {stmtOpen && uidForStatement && (
        <WalletStatementModal
          open={stmtOpen}
          userId={uidForStatement}
          userTitle={titleFrom(user)}
          onClose={() => setStmtOpen(false)}
        />
      )}
    </section>
  );
}
