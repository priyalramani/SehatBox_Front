// src/pages/user/MealPlan.jsx
import { useEffect, useState } from "react";
import api from "../../lib/api";

const PLACEHOLDER = "https://via.placeholder.com/1000x600?text=Meal+Image";

export default function MealPlan() {
  const [dish, setDish] = useState(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  const [showOrderModal, setShowOrderModal] = useState(false);
  const [instructions, setInstructions] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [qty, setQty] = useState(1);

  // login modal stuff
  const [loginStage, setLoginStage] = useState("NONE"); // NONE | MOBILE | OTP
  const [loginMobile, setLoginMobile] = useState("");
  const [loginOtp, setLoginOtp] = useState("");
  const [loginBusy, setLoginBusy] = useState(false);
  const [loginMsg, setLoginMsg] = useState("");
  const [resumeAfterLogin, setResumeAfterLogin] = useState(false);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        setLoading(true);
        const { data } = await api.get("/api/dishes/active");
        if (!alive) return;
        setDish(data);
      } catch (e) {
        if (!alive) return;
        setErr(e?.response?.data?.error || "Failed to load meal");
      } finally {
        alive && setLoading(false);
      }
    })();
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    const hasModal = showOrderModal || loginStage !== "NONE";
    if (!hasModal) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, [showOrderModal, loginStage]);

  const imageSrc = (() => {
    if (!dish) return PLACEHOLDER;
    if (Array.isArray(dish.image_url) && dish.image_url.length > 0) return dish.image_url[0];
    if (typeof dish.image_url === "string" && dish.image_url) return dish.image_url;
    return PLACEHOLDER;
  })();

  const price = Number(dish?.price) || 0;
  const amount = price * qty;
  const fmt = (n) =>
    new Intl.NumberFormat("en-IN", { minimumFractionDigits: 0, maximumFractionDigits: 2 })
      .format(Number(n || 0));

  const onConfirmClick = () => {
    const uid = localStorage.getItem("User_uuid");
    if (!uid) {
      setResumeAfterLogin(true);
      startLogin();
      return;
    }
    setErr("");     // reset any previous error
    setQty(1);
    setShowOrderModal(true);
  };

  const startLogin = () => {
    setLoginMsg("");
    setLoginMobile("");
    setLoginOtp("");
    setLoginStage("MOBILE");
  };

  const submitMobile = async () => {
    setLoginMsg("");
    if (loginMobile.length !== 10) return setLoginMsg("Enter 10-digit mobile");
    setLoginBusy(true);
    try {
      await api.post("/api/auth/request-otp", { mobile: loginMobile });
      setLoginStage("OTP");
      setLoginMsg("OTP sent. (Dev: any 4-digit works)");
    } catch (e) {
      setLoginMsg(e?.response?.data?.message || "Failed to request OTP");
    } finally {
      setLoginBusy(false);
    }
  };

  const submitOtp = async () => {
    setLoginMsg("");
    if (loginOtp.length !== 4) return setLoginMsg("Enter 4-digit OTP");
    setLoginBusy(true);
    try {
      const { data } = await api.post("/api/auth/verify-otp", {
        mobile: loginMobile,
        otp: loginOtp,
      });
      localStorage.setItem("auth_token", data.accessToken);
      localStorage.setItem("User_uuid", data.user.user_uuid);
      localStorage.setItem("Mobile", data.user.mobile_number);

      setLoginStage("NONE");
      if (resumeAfterLogin) {
        setResumeAfterLogin(false);
        setQty(1);
        setShowOrderModal(true);
      }
    } catch (e) {
      setLoginMsg(e?.response?.data?.message || "OTP verification failed");
    } finally {
      setLoginBusy(false);
    }
  };

  const placeOrder = async () => {
    setSubmitting(true);
    // keep whatever error was displayed visible until a new attempt
    try {
      const dishUuid = dish?.dish_uuid || dish?._id;
      if (!dishUuid) throw new Error("Dish id missing");

      await api.post("/api/orders", {
        dish_details: [{ dish_uuid: dishUuid, quantity: qty }],
        meal_uuid: null,
        instructions,
      });

      alert("✅ Order placed!");
      setShowOrderModal(false);
      setInstructions("");
      setQty(1);
      setErr("");
    } catch (e) {
      const msg = e?.response?.data?.message || e?.message || "Failed to place order";
      setErr(msg);        // show inside the modal
      alert(msg);         // extra visibility for now
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <div className="min-h-screen grid place-items-center">Loading…</div>;
  if (err && !showOrderModal) return <div className="min-h-screen grid place-items-center text-red-600">{err}</div>;
  if (!dish) return <div className="min-h-screen grid place-items-center">No active meal.</div>;

  return (
    <div className="min-h-screen bg-white grid place-items-start px-4">
      <div className="w-full max-w-md mx-auto">
        <h1 className="text-2xl font-semibold text-center mt-4 mb-3">Tomorrow’s Meal</h1>

        <img
          src={imageSrc}
          alt={dish?.title || "Meal"}
          className="w-full h-[240px] sm:h-[260px] object-cover rounded-2xl"
          loading="lazy"
        />

        <div className="pt-4">
          <h2 className="text-[28px] font-extrabold text-center">
            {dish?.title || "Today’s Meal"}
          </h2>

          <p className="mt-1 text-[16px] font-semibold text-center text-neutral-800">
            What Am I Eating
          </p>

          {dish?.ingredients && (
            <p className="mt-3 text-[15px] leading-relaxed text-neutral-700 text-left">
              {dish.ingredients}
            </p>
          )}

          <button
            onClick={onConfirmClick}
            className="mt-5 w-full h-12 rounded-xl bg-green-600 text-white text-lg font-semibold hover:bg-green-700 transition"
          >
            Confirm
          </button>
          <button
            onClick={() => alert("👌 Skipped.")}
            className="block mx-auto mt-4 text-blue-600 font-semibold hover:underline"
          >
            SKIP this meal
          </button>
        </div>
      </div>

      {/* ====== Order Modal ====== */}
      {showOrderModal && (
        <div
          className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/30 backdrop-blur-[1px] p-4"
          onClick={() => setShowOrderModal(false)}
        >
          <div
            className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-xl font-bold mb-4">Your Order</h3>

            <div className="border rounded-xl p-3 bg-gray-50">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm text-gray-500">Price</div>
                  <div className="text-lg font-semibold">₹{fmt(price)}</div>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    className="w-10 h-10 rounded-lg bg-gray-200 text-xl font-bold disabled:opacity-50"
                    onClick={() => setQty((q) => Math.max(1, q - 1))}
                    disabled={qty <= 1}
                    aria-label="Decrease quantity"
                  >
                    –
                  </button>
                  <div className="min-w-[48px] text-center text-lg font-semibold">{qty}</div>
                  <button
                    className="w-10 h-10 rounded-lg bg-gray-200 text-xl font-bold"
                    onClick={() => setQty((q) => q + 1)}
                    aria-label="Increase quantity"
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between border-t pt-3">
                <div className="text-sm text-gray-600">Amount</div>
                <div className="text-2xl font-extrabold">₹{fmt(amount)}</div>
              </div>

              {/* ERROR (shown when balance is low etc.) */}
              {err && (
                <div className="mt-3 text-sm text-red-600">
                  {err}
                </div>
              )}
            </div>

            <h4 className="text-base font-semibold mt-5 mb-2">Cooking Instructions</h4>
            <textarea
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              placeholder="Any cooking instructions…"
              className="w-full border rounded-xl p-3 h-20 text-sm text-gray-700 placeholder-gray-400"
            />

            <div className="flex items-center justify-between mt-5">
              <button
                onClick={() => setShowOrderModal(false)}
                className="px-4 py-2 rounded-lg bg-gray-200"
              >
                Cancel
              </button>
              <button
                onClick={placeOrder}
                disabled={submitting}
                className="px-5 py-2 rounded-lg bg-green-600 text-white font-semibold"
              >
                {submitting ? "Submitting..." : "Submit • ₹" + fmt(amount)}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Login: Mobile */}
      {loginStage === "MOBILE" && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/25 p-4"
          onClick={() => setLoginStage("NONE")}
        >
          <div
            className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-xl font-bold mb-4">Login</h3>
            <label className="text-sm">Enter 10-digit mobile number</label>
            <input
              value={loginMobile}
              onChange={(e) => setLoginMobile(e.target.value.replace(/\D/g, "").slice(0, 10))}
              inputMode="numeric"
              placeholder="Mobile"
              className="mt-1 w-full border rounded-lg p-3"
            />
            <div className="flex justify-end gap-3 mt-4">
              <button onClick={() => setLoginStage("NONE")} className="px-4 py-2 rounded-lg bg-gray-200">
                Cancel
              </button>
              <button onClick={submitMobile} disabled={loginBusy} className="px-4 py-2 rounded-lg bg-green-600 text-white">
                {loginBusy ? "Please wait…" : "Submit"}
              </button>
            </div>
            {loginMsg && <p className="mt-3 text-sm text-center">{loginMsg}</p>}
          </div>
        </div>
      )}

      {/* Login: OTP */}
      {loginStage === "OTP" && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/25 p-4"
          onClick={() => setLoginStage("NONE")}
        >
          <div
            className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-xl font-bold mb-4">Enter OTP</h3>
            <input
              value={loginOtp}
              onChange={(e) => setLoginOtp(e.target.value.replace(/\D/g, "").slice(0, 4))}
              inputMode="numeric"
              placeholder="4-digit OTP"
              className="mt-1 w-full border rounded-lg p-3 tracking-widest text-center"
            />
            <div className="flex justify-end gap-3 mt-4">
              <button onClick={() => setLoginStage("MOBILE")} className="px-4 py-2 rounded-lg bg-gray-200">
                Back
              </button>
              <button onClick={submitOtp} disabled={loginBusy} className="px-4 py-2 rounded-lg bg-green-600 text-white">
                {loginBusy ? "Verifying…" : "Submit"}
              </button>
            </div>
            {loginMsg && <p className="mt-3 text-sm text-center">{loginMsg}</p>}
          </div>
        </div>
      )}
    </div>
  );
}
